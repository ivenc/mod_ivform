<?php 
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

$br = "<br/>";
echo "Простой шаблон:".$br;