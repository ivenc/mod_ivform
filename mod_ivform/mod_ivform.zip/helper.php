<?php
/**
* Helper class for IVENC Form module
*
* @package    Joomla.Ivenc
* @subpackage Modules
* @link http://ivenc.com
* @license	GNU/GPL
*/
class ModIvFormHelper
{
    /**
     * Retrieves the message
     *
     * @param array $params An object containing the module parameters
     * @access public
     */    
    public static function getIvForm( $params )
    {
        return 'Form ... Form';
    }
}